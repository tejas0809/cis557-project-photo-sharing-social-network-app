'user strict';

app.controller('homeController', function ($scope, $location, $timeout, appService) {

    $scope.data = {
        UserID : '100',
        PostDate : '20190101',
        Caption : '',
    };


    $scope.uploadPost = () => {
        appService.httpCall({
            url: '/api/login',
            params: {
                'username': $scope.data.loginUsername,
                'password': $scope.data.loginPwd
            }
        })
        .then((response) => {
            // $location.path(`/home/${response.userId}`);
            alert(response.message);
            $scope.$apply();
        })
        .catch((error) => {
            alert(error.message);
        });
    }
});