'use strict';

class AppService{
    constructor($http){
        this.$http = $http;
    }
    
    httpCall(httpData){
        if (httpData.url === undefined || httpData.url === null || httpData.url === ''){
            alert(`Invalid HTTP call`);
        }
        const HTTP = this.$http;
        const params = httpData.params;
        return new Promise( (resolve, reject) => {
            HTTP.post(httpData.url, params).then( (response) => {
                resolve(response.data);
            }).catch( (response, status, header, config) => {
                reject(response.data);
            });
        });
    }

}