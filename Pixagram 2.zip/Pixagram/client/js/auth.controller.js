'user strict';

app.controller('authController', function ($scope, $location, $timeout, appService) {

    $scope.data = {
        regUsername : '',
        regPwd : '',
        usernameAvailable : false,
        loginUsername : '',
        loginPwd : ''
    };

    /* usernamme check variables starts*/
    let TypeTimer;
    const TypingInterval = 800;
    /* usernamme check variables ends*/

    
    $scope.initiateCheckUserName = () => {
        $scope.data.usernameAvailable = false;
        $timeout.cancel(TypeTimer);
        TypeTimer = $timeout( () => {
            appService.httpCall({
                url: '/api/usernameCheck',
                params: {
                    'username': $scope.data.regUsername
                }
            })
            .then((response) => {
                $scope.$apply( () =>{
                    $scope.data.usernameAvailable = response.error ? true : false;
                });
            })
            .catch((error) => {
                $scope.$apply(() => {
                    $scope.data.usernameAvailable = true;
                });
               
            });
        }, TypingInterval);
    }

    $scope.clearCheckUserName = () => {
        $timeout.cancel(TypeTimer);
    }

    $scope.registerUser = () => {
        appService.httpCall({
            url: '/api/registerUser',
            params: {
                'username': $scope.data.regUsername,
                'password': $scope.data.regPwd
            }
        })
        .then((response) => {
            $location.path(`/home/${response.userId}`);
            $scope.$apply();
        })
        .catch((error) => {
            alert(error.message);
        });
    }

    $scope.loginUser = () => {
        appService.httpCall({
            url: '/api/login',
            params: {
                'username': $scope.data.loginUsername,
                'password': $scope.data.loginPwd
            }
        })
        .then((response) => {
            // $location.path(`/home/${response.userId}`);
            alert(response.message);
            $scope.$apply();
        })
        .catch((error) => {
            alert(error.message);
        });
    }
});