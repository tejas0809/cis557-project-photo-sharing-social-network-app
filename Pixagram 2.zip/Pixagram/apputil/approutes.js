'use strict';

const path = require('path');
const usersRoute = require('./api/routes/user');
const postRoute = require('./api/routes/post');

class AppRoutes{

	constructor(app){
		this.app = app;
	}
	
	appRoutes() {
		// Configure API and add routes to App
		new usersRoute(this.app).configureAPI();
		new postRoute(this.app).configureAPI();

		
		
		// Routes for client side views index.html...
		this.app.get('*',(request,response) =>{
			response.sendFile(path.join(__dirname + '../../client/views/index.html'));
			
		});	
	}

	routesConfig(){
		this.appRoutes();
	}
}
module.exports = AppRoutes;