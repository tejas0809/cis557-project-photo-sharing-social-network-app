const mysql = require('mysql');

class AppDb {
	constructor(config) {
		// Method 1:
		// this.connection = mysql.createConnection({			
		// 	host: '127.0.0.1',		
		// 	user: 'root',
		// 	password: 'kanika123',
		// 	database: 'photoshare'
		// });

		// this.connection.connect(function(err) {
		// 	if (err) throw err;
		// 	console.log("MYSQL Connected!")
		// });
		//               OR


		// Method 2: 
		 
		this.connection = mysql.createPool({
			connectionLimit: 100,
			host: '127.0.0.1',
			user: 'root',
			password: 'kanika123',
			database: 'photoshare',
			debug: false
		});
	}
	
	query(sql, args) {
		return new Promise((resolve, reject) => {
			this.connection.query(sql, args, (err, rows) => {
				if (err)
					return reject(err);
				resolve(rows);
			});
		});
	}
	
	close() {
		return new Promise((resolve, reject) => {
			this.connection.end(err => {
				if (err)
					return reject(err);
				resolve();
			});
		});
	}
}
module.exports = new AppDb();