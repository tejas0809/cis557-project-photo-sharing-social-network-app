'use strict';

class User {
    constructor(user) {       
        this.username = user.username || null;
        this.password = user.password || null;
    }
}
module.exports = User;