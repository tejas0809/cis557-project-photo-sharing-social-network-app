'use strict';

class Post {
    constructor(post) {       
        this.PostID = post.PostID  || null;
        this.PostDate = post.PostDate || null;		
        this.PhotoUrl =  post.PhotoUrl || null;          
        this.Caption  = post.Caption || null;         
        this.UserID = post.UserID || null;
    }
}
module.exports = Post;