'use strict';

const helper = require('../controllers/user');
const user = require('../models/user');

class UsersRoute{

    constructor(app){

		this.app = app;
    }
    
    configureAPI() {
        this.app.post('/api/usernameCheck',async (request,response) =>{
			const newUser = new user(request.body);
			// const username = request.body.username;
			const username = newUser.username;
			if (username === "" || username === undefined || username === null) {
				response.status(412).json({
					error : true,
					message : `Enter username`
				});
			} else {
				const data = await helper.userNameCheck(username.toLowerCase());
				if (data[0]['count'] > 0) {
					response.status(401).json({
						error:true,
						message: 'Username exists'
					});
				} else {
					response.status(200).json({
						error:false,
						message: 'Username is available'
					});
				}
			}
		});		

		this.app.post('/api/registerUser', async (request,response) => {
			const registrationResponse = {}
			// const data = {
			// 	username : (request.body.username).toLowerCase(),
			// 	password : request.body.password
			// };	
			const data = new user(request.body);	
			if(data.username === '') {
	            registrationResponse.error = true;
	            registrationResponse.message = `Enter username`;
	            response.status(412).json(registrationResponse);
	        }else if(data.password === ''){				            
	            registrationResponse.error = true;
	            registrationResponse.message = `Enter password`;
	            response.status(412).json(registrationResponse);
	        }else{	        	
				const result = await helper.registerUser( data );
				if (result === null) {
					registrationResponse.error = true;
					registrationResponse.message = `Registraion failed!`;
					response.status(417).json(registrationResponse);
				} else {
					registrationResponse.error = false;
					registrationResponse.userId = result.insertId;
					registrationResponse.message = `Registration successful.`;
					response.status(200).json(registrationResponse);
				}
	        }
		});

		this.app.post('/api/login',async (request,response) =>{
			const loginResponse = {}
			// const data = {
			// 	username : (request.body.username).toLowerCase(),
			// 	password : request.body.password
			// };
			const data = new user(request.body);	
			if(data.username === '' || data.username === null) {
	            loginResponse.error = true;
	            loginResponse.message = `Enter username`;
	            response.status(412).json(loginResponse);
	        }else if(data.password === '' || data.password === null){				            
	            loginResponse.error = true;
	            loginResponse.message = `Enter Password`;
	            response.status(412).json(loginResponse);
	        }else{
				const result = await helper.loginUser(data);
				if (result === null || result.length === 0) {
					loginResponse.error = true;
					loginResponse.message = `Invalid username or password`;
					response.status(401).json(loginResponse);
				} else {
					loginResponse.error = false;
					loginResponse.userId = result[0].id;
					loginResponse.message = `Logged-in successfully!`;
					response.status(200).json(loginResponse);
				}
	        }
		});
    }
}
module.exports = UsersRoute;