'use strict';

const helper = require('../controllers/post');
const post = require('../models/post');

const multer = require("multer");
const path = require('path');
const storage = multer.diskStorage({
	destination: (req, file, cb) => {		
		cb(null, "./uploads");
	},
	filename: (req, file, cb) => {
		const data = new post(req.body);		
		const prefix = data.UserID + '_';
		console.log("Prefix : " + prefix);
		const ext = path.extname(file.originalname).toLowerCase();
		cb(null, `${prefix}${Date.now()}${ext}`);
	}
});

const upload = multer({
storage: storage,
fileFilter: (req, file, cb) => {
	const ext = path.extname(file.originalname).toLowerCase();

	if (ext != ".jpg" && ext != ".png" && ext != ".jpeg") {
	return cb(new Error("Please upload an image"));
	}

	cb(null, true);
},
limits: { fileSize: 1000000 }
});

class PostRoute{

    constructor(app){

		this.app = app;
    }
    
    configureAPI() {		
		this.app.get('/api/post', async (request,response) => {
            const registrationResponse = {}						        	
            const result = await helper.get();
            if (result === null) {
                registrationResponse.error = true;
                registrationResponse.message = `Get all posts failed!`;
                response.status(417).json(registrationResponse);
            } else {
                registrationResponse.error = false;
                registrationResponse.data = result;
                registrationResponse.message = `Get all posts successful`;
                response.status(200).json(registrationResponse);
            }	        
		});
		
		this.app.get('/api/post/:id', async (request,response) => {
            const registrationResponse = {}		
            const id = request.params.id;					        	
            const result = await helper.getByID( id );
            if (result === null) {
                registrationResponse.error = true;
                registrationResponse.message = `Get post failed!`;
                response.status(417).json(registrationResponse);
            } else {
                registrationResponse.error = false;
                registrationResponse.data = result;
                registrationResponse.message = `Get post successful`;
                response.status(200).json(registrationResponse);
            }	        
		});

		this.app.post('/api/post', upload.single("image"), async (request,response) => {
			const registrationResponse = {}				
			const data = new post(request.body);	
			if (!request.file) {
				registrationResponse.error = true;
				registrationResponse.message = `No image uploaded !`;
				response.status(412).json(registrationResponse);
			}
			else {				
				if(data.PhotoUrl === '') {
					registrationResponse.error = true;
					registrationResponse.message = `Upload photo`;
					response.status(412).json(registrationResponse);
				}else if(data.Caption === ''){				            
					registrationResponse.error = true;
					registrationResponse.message = `Enter caption`;
					response.status(412).json(registrationResponse);
				}else{	   
					// Physical Path
					// const photoUrl = __dirname + "\\uploads\\" + request.file.path;
					//                             Or
					// Virtual Path
					// const photoUrl = request.protocol + '://' + request.hostname + '/' + request.file.path.replace('\\','/');
					const photoUrl = request.protocol + '://' + request.get('host') + '/' + request.file.path.replace('\\','/');
					// console.log('storage location is ', photoUrl);  
					data.PhotoUrl = photoUrl;  	

					const result = await helper.create( data );
					if (result === null) {
						registrationResponse.error = true;
						registrationResponse.message = `Post create failed!`;
						response.status(417).json(registrationResponse);
					} else {
						registrationResponse.error = false;
						registrationResponse.PostID = result.insertId;
						registrationResponse.PhotoUrl = photoUrl;
						console.log('storage location is ', photoUrl);  
						registrationResponse.message = `Post created successfully.`;
						response.status(200).json(registrationResponse);
					}
				}
			}	
		});

        this.app.put('/api/post/:id', async (request,response) => {
            const registrationResponse = {}		
            const id = request.params.id;		
			const data = new post(request.body);	
			if(data.PhotoUrl === '') {
	            registrationResponse.error = true;
	            registrationResponse.message = `Upload photo`;
	            response.status(412).json(registrationResponse);
	        }else if(data.Caption === ''){				            
	            registrationResponse.error = true;
	            registrationResponse.message = `Enter caption`;
	            response.status(412).json(registrationResponse);
	        }else{	        	
				const result = await helper.update( id, data );
				if (result === null) {
					registrationResponse.error = true;
					registrationResponse.message = `Post update failed!`;
					response.status(417).json(registrationResponse);
				} else {
					registrationResponse.error = false;
					registrationResponse.message = `Post updated successfully.`;
					response.status(200).json(registrationResponse);
				}
	        }
        });
        
        this.app.delete('/api/post/:id', async (request,response) => {
            const registrationResponse = {}		
            const id = request.params.id;					        	
            const result = await helper.delete( id );
            if (result === null) {
                registrationResponse.error = true;
                registrationResponse.message = `Post delete failed!`;
                response.status(417).json(registrationResponse);
            } else {
				registrationResponse.error = false;
                registrationResponse.message = `Post deleted successfully.`;
                response.status(200).json(registrationResponse);
            }	        
		});				
    }
}
module.exports = PostRoute;