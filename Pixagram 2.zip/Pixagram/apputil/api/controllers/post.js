'user strict';
const DB = require('../../appdb');

class PostController{
	
	constructor(app){
		this.db = DB;
	}

	/* get all posts */
  async get(params){
		try {
			return await this.db.query(`SELECT * FROM posts Order by PostID DESC`, []);
		} catch (error) {
			return null;
		}
	}	
	
	
	/* get single post by PostID  */
	async getByID(id){
		try {
			return await this.db.query(`SELECT * FROM posts Where PostID = ?`, [id]);
		} catch (error) {
			return null;
		}
  }
		
	/* insert new post */
	async create(params){
		try {
			return await this.db.query("INSERT INTO posts (`PostDate`,`PhotoUrl`,`Caption`,`UserID` ) VALUES (?,?,?,?)", [params.PostDate, params.PhotoUrl, params.Caption, params.UserID]);
		} catch (error) {
			console.error(error);
			return null;
		}
  }
		
	/* update post */
  async update(id, params){
		try {
			return await this.db.query("UPDATE posts SET `PostDate` = ?, `PhotoUrl` = ?, `Caption` = ?, `UserID` = ? Where `PostID` = ?", [params.PostDate, params.PhotoUrl, params.Caption, params.UserID, id]);
		} catch (error) {
			console.error(error);
			return null;
		}
	}
	 
	/* delete post by PostID */
  async delete(id){
		try {
			return await this.db.query(`DELETE FROM posts Where PostID = ?`, [id]);
		} catch (error) {
			return null;
		}
  }
}
module.exports = new PostController();