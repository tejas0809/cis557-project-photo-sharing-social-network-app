'user strict';
const DB = require('../../appdb');

class UsersController{
	
	constructor(app){
		this.db = DB;
	}

	async userNameCheck (username){
		return await this.db.query(`SELECT count(username) as count FROM users WHERE LOWER(username) = ?`, `${username}`);
	}

	async registerUser(params){
		try {
			return await this.db.query("INSERT INTO users (`username`,`pwd`) VALUES (?,?)", [params.username, params.password]);
		} catch (error) {
			console.error(error);
			return null;
		}
	}

	async loginUser(params){
		try {
			return await this.db.query(`SELECT UserID FROM users WHERE LOWER(username) = ? AND pwd = ?`, [params.username,params.password]);
		} catch (error) {
			return null;
		}
	}	
}
module.exports = new UsersController();