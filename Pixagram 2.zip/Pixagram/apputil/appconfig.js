const cors = require('cors');

class AppConfig{
	// corsOptions = {
	// 	origin: '*',
	// 	optionsSuccessStatus: 200,
	// };

	constructor(app){
		// cors
		//app.use(cors(this.corsOptions));

		// Setting .html as the default template extension
		app.set('view engine', 'html');

		// set to 'express' where to find views in client app
		app.set('views', (__dirname + '/../views'));

		// set to 'express', where to find index.html 
		app.use(require('express').static(require('path').join('client')));
	}
}
module.exports = AppConfig;